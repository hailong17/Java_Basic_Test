package Excercise2;

public class Operation {
	public static void main(String[] args) {
		int result1 = -5 + 8 * 6;
		int result2 = (55+9) % 9;
		int result3 = 20+ (-3*5)/8;
		int result4 = 5 + 15/3*2 - 8%3;
		System.out.println("Output1: " + result1);
		System.out.println("Output2: " + result2);
		System.out.println("Output1: " + result3);
		System.out.println("Output2: " + result4);
	}
}
